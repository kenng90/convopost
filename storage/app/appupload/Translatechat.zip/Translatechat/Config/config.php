<?php

return [
    'name' => 'Translatechat'
];
