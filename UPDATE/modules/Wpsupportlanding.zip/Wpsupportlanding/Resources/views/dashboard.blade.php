
@hasrole('owner')
<div class="row">
    <div class="col-xl-3 col-md-6">
    </div>
</div>
@endhasrole