<?php

return [
    'name' => 'Reminders'
];
