<?php

return [
    'name' => 'Themes'
];
